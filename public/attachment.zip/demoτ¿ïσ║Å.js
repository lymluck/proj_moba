import WebSocket from 'ws';

let socket;
let isConnectted = false;

// 发送消息
const emit = (type, params) => {
  socket.send(JSON.stringify(Object.assign({}, { type }, params)));
};

// 计算两点之间距离
const getDistance = (p1, p2) => (
  Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2))
);

// 状态更新
const update = (myCamp, state) => {
  const { towers, heros } = state;
  const heroCmds = {};

  // 优先攻击靠近的英雄
  heros.forEach((hero) => {
    if (hero.camp !== myCamp || heroCmds[hero.id]) {
      return;
    }

    // 计算离每个英雄最近的英雄
    let closeHero;
    let minDistance;
    heros.forEach((opHero) => {
      if (opHero.camp === myCamp) {
        return;
      }

      const distance = getDistance(hero.position, opHero.position);
      if (
        distance < 400 &&
        opHero.status !== 'dead' &&
        (!closeHero || distance < minDistance)
      ) {
        closeHero = opHero;
        minDistance = distance;
      }
    });

    // 攻击英雄
    if (closeHero) {
      heroCmds[hero.id] = {
        // 优先使用技能
        type: hero.fireCD === 0 ? 'fire' : 'attack',
        params: {
          heroId: hero.id,
          targetType: 'hero',
          targetId: closeHero.id,
        },
      };
    }
  });

  // 其次占塔
  heros.forEach((hero) => {
    if (hero.camp !== myCamp || heroCmds[hero.id]) {
      return;
    }

    // 计算离每个英雄最近的塔
    let closeTower;
    let minDistance;
    towers.forEach((tower) => {
      if (tower.camp === myCamp) {
        return;
      }

      const distance = getDistance(hero.position, tower.position);
      if (!closeTower || distance < minDistance) {
        closeTower = tower;
        minDistance = distance;
      }
    });

    // 攻击塔
    if (closeTower) {
      heroCmds[hero.id] = {
        type: 'attack',
        params: {
          heroId: hero.id,
          targetType: 'tower',
          targetId: closeTower.id,
        },
      };
    }
  });

  // 传递命令给服务器
  heros.forEach((hero) => {
    if (hero.camp !== myCamp) {
      return;
    }

    if (heroCmds[hero.id]) {
      emit(heroCmds[hero.id].type, heroCmds[hero.id].params);
    } else {
      // 如果没有可执行的命令，则攻击敌方未死的英雄
      heros.forEach((opHero) => {
        if (opHero.camp !== myCamp && opHero.status !== 'dead') {
          emit('attack', {
            heroId: hero.id,
            targetType: 'hero',
            targetId: opHero.id,
          });
        }
      });
    }
  });
};

// 创建websocket
const connect = () => {
  isConnectted = true;
  socket = new WebSocket('ws://mobaai.smartstudy.com:7788');

  // 连接成功
  socket.on('open', () => {
    emit('join', { gameId: '00v00', token: 'test-token' });
  });

  // 接收消息
  socket.on('message', (message) => {
    const params = JSON.parse(message);

    // 选择英雄
    if (params.type === 'picking') {
      emit(
        'pickHero',
        { heros: ['shooter', 'shooter', 'shooter', 'warrior', 'warrior'] },
      );
    }

    // 状态更新
    if (params.type === 'update') {
      update(params.myCamp, params.state);
    }

    // 命令错误
    if (params.type === 'cmdError') {
      console.log(params);
    }
  });

  // 错误
  socket.on('error', () => {
    isConnectted = false;
  });

  // 断开连接
  socket.on('close', () => {
    isConnectted = false;
  });
};
connect();

// 健康检查
setInterval(() => {
  if (!isConnectted) {
    connect();
  }
}, 20);
